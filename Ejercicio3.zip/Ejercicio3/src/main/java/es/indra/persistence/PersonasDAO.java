package es.indra.persistence;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Repository;

import es.indra.models.Persona;

@Repository
public class PersonasDAO extends JdbcDaoSupport{

	private RowMapper<Persona> mapeadorPersona;

	public PersonasDAO(RowMapper<Persona> mapeadorPersona, DriverManagerDataSource dataSource) {
		this.mapeadorPersona = mapeadorPersona;
		setDataSource(dataSource);
	}

	public List<Persona> consultarTodos() {
		return getJdbcTemplate().query("select * from PERSONAS", mapeadorPersona);
	}

	public Persona buscarPersona(String dni) {
		return getJdbcTemplate().queryForObject("select * from PERSONAS where DNI=?", mapeadorPersona, dni);
	}

	public void altaPersona(Persona persona) {
		String sql = "insert into PERSONAS values (?,?,?,?,?)";
		getJdbcTemplate().update(sql, persona.getDni(), persona.getNombre(), persona.getFechaNac(), persona.getDireccion(),
				persona.getTelefono());
	}

	public void bajaPersona(String dni) {
		getJdbcTemplate().update("delete from PERSONAS where DNI=?", dni);
	}

	public void modificarDireccion(String dni, String nuevaDireccion) {
		getJdbcTemplate().update("update PERSONAS set DIR=? where DNI=?", nuevaDireccion, dni);
	}

	public void crearTabla() {
		// Crear la tabla
		getJdbcTemplate().update("DROP TABLE PERSONAS if exists");
		String sql = "CREATE TABLE PERSONAS " + "(DNI VARCHAR(15) not NULL, " + "NOMBRE VARCHAR(45), "
				+ "FECNAC DATE, DIR VARCHAR(45), TFNO INTEGER," + "PRIMARY KEY (DNI) )";
		getJdbcTemplate().update(sql);

		// Crear 5 personas en la tabla
		sql = "insert into PERSONAS values (?,?,?,?,?)";
		getJdbcTemplate().update(sql, "1111111-A", "Juan", new Date("10/12/1987"), "Real, 27 Madrid", 616111111);
		getJdbcTemplate().update(sql, "2222222-B", "Maria", new Date("1/2/1989"), "Diagonal, 87 Barcelona", 616222222);
		getJdbcTemplate().update(sql, "3333333-C", "Pedro", new Date("12/9/2001"), "Mayor, 31 Toledo", 616333333);
		getJdbcTemplate().update(sql, "4444444-D", "Marta", new Date("16/4/2006"), "Camino, 68 Coruña", 616444444);
		getJdbcTemplate().update(sql, "5555555-E", "Alvaro", new Date("14/3/2003"), "Alfonso, 22 Ciudad Real", 616555555);
	}


}
