package es.indra;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.models.Persona;
import es.indra.persistence.PersonasDAO;

@SpringBootApplication
public class Ejercicio1Application implements CommandLineRunner{
	
	// En versiones nuevas de Spring no se recomiendo utilizar @Autowired por seguridad
	// A cambio se inyecta a traves del constructor
	//@Autowired
	private PersonasDAO dao;
	
	public Ejercicio1Application(PersonasDAO dao) {
		this.dao = dao;
	}

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio1Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		dao.crearTabla();
		
		dao.altaPersona(new Persona("6666666-F", "Elena", new Date(1997, 12, 26), "Gran Via, 12 Madrid", 616666666));
		
		dao.modificarDireccion("4444444-D", "Alcala, 27 Madrid");
		
		dao.bajaPersona("3333333-C");
		
		dao.consultarTodos().forEach(System.out::println);
		System.out.println("----------------------------");
		
		System.out.println("Encontrado: " + dao.buscarPersona("2222222-B"));
		
	}

}
