package es.indra.models;

import java.io.Serializable;
import java.sql.Date;

public class Persona implements Serializable {

	private String dni;
	private String nombre;
	private Date fechaNac;
	private String direccion;
	private int telefono;

	public Persona() {
		// TODO Auto-generated constructor stub
	}

	public Persona(String dni, String nombre, Date fechaNac, String direccion, int telefono) {
		super();
		this.dni = dni;
		this.nombre = nombre;
		this.fechaNac = fechaNac;
		this.direccion = direccion;
		this.telefono = telefono;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Date getFechaNac() {
		return fechaNac;
	}

	public void setFechaNac(Date fechaNac) {
		this.fechaNac = fechaNac;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

	@Override
	public String toString() {
		return "Persona [dni=" + dni + ", nombre=" + nombre + ", fechaNac=" + fechaNac + ", direccion=" + direccion
				+ ", telefono=" + telefono + "]";
	}

}
