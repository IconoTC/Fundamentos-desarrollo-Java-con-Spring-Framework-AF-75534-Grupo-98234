package es.indra;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import es.indra.business.Aseguradora;
import es.indra.models.Coche;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// 1º Escanea todos los paquetes que comienzan por es.indra.xxxx 
		// 2ª por cada bean declarado crear el bean y lo mete en el contenedor
		AnnotationConfigApplicationContext contenedor = new AnnotationConfigApplicationContext();
		contenedor.scan("es.indra");
		contenedor.refresh();
		
		// Recuperar un bean del contenedor
		Coche coche = (Coche) contenedor.getBean("coche");   // id del bean es coche
		
		// Recuperar el bean aseguradora
		Aseguradora aseguradora = contenedor.getBean("aseguradora", Aseguradora.class);
		
		// Ejecutar
		aseguradora.arreglarCoche(coche);

	}

}
