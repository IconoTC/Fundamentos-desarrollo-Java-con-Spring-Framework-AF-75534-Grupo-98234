package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import es.indra.models.Coche;

@Service
public class Aseguradora {

	@Value("Mapfre")
	private String nombre;

	@Autowired  // No me permite poner el id del bean
	@Qualifier(value = "tallerPintura")
	private ITaller taller;

	public void arreglarCoche(Coche coche) {
		taller.reparar(coche);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public ITaller getTaller() {
		return taller;
	}

	public void setTaller(ITaller taller) {
		this.taller = taller;
	}

}
