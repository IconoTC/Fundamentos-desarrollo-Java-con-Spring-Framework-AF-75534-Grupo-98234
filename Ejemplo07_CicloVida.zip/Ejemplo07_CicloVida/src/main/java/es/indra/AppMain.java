package es.indra;

import java.util.stream.Stream;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.models.Empresa;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// 1º Leer el applicationContext.xml,  
		// 2ª por cada bean declarado crear el bean y lo mete en el contenedor
		AbstractApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Empresa empresa = contenedor.getBean("empresa", Empresa.class);
		
		System.out.println("------- Empleados -------");
		empresa.getEmpleados().forEach(System.out::println);
		
		System.out.println("------- Proyectos -------");
		empresa.getProyectos().forEach(System.out::println);
		
		System.out.println("------- Equipo -------");
		Stream.of(empresa.getEquipo()).forEach(System.out::println);
		
		System.out.println("------- Jefes de Proyecto -------");
		empresa.getJefesProyecto().entrySet().forEach(System.out::println);
		
		System.out.println("------- Emails -------");
		empresa.getEmails().entrySet().forEach(System.out::println);
		
		// Eliminar todos los beans del contenedor
		contenedor.registerShutdownHook();

	}

}
