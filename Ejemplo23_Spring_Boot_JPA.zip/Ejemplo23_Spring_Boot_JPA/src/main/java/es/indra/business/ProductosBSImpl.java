package es.indra.business;

import java.util.List;

import org.springframework.stereotype.Service;

import es.indra.entities.Producto;
import es.indra.persistence.ProductosDAO;

@Service
public class ProductosBSImpl implements IProductosBS {

	private ProductosDAO dao;

	public ProductosBSImpl(ProductosDAO dao) {
		super();
		this.dao = dao;
	}

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(int id) {
		return dao.findById(id).orElse(new Producto());
	}

	@Override
	public boolean insertarProducto(Producto producto) {
		Producto insertado = dao.save(producto);
		return insertado != null;
	}

	@Override
	public boolean eliminarProducto(int id) {
		dao.deleteById(id);
		return true;
	}

	@Override
	public Producto modificarProducto(Producto producto) {
		return dao.save(producto);
	}

}
