package es.indra.persistence;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.NativeQuery;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import es.indra.entities.Producto;

// Podemos exponer este DAO como un servicio REST
@RepositoryRestResource(path = "productos", collectionResourceRel = "PRODUCTOS")
// Spring Boot detecta que heredamos de xxxRepository y entonces genera un bean de ProductosDAO
public interface ProductosDAO extends JpaRepository<Producto, Integer>{
	
	// Podemos crear metodos personalizados utilizando keywords
	// https://docs.spring.io/spring-data/jpa/reference/repositories/query-keywords-reference.html
	
	// Para consultar todos los metodos personalizados
	// http://localhost:8080/productos/search
	
	// http://localhost:8080/productos/search/findByDescripcion?descripcion=Scanner
	public List<Producto> findByDescripcion(String descripcion);
	
	// http://localhost:8080/productos/search/findByPrecioBetween?min=50&max=100
	public List<Producto> findByPrecioBetween(double min, double max);
	
	// http://localhost:8080/productos/search/findByPrecioBetweenOrderByDescripcion?min=50&max=100
	public List<Producto> findByPrecioBetweenOrderByDescripcion(double min, double max);
	
	// http://localhost:8080/productos/search/findByPrecioBetweenOrderByDescripcionDesc?min=50&max=100
	public List<Producto> findByPrecioBetweenOrderByDescripcionDesc(double min, double max);
	
	
	// Declarar nuestras propies Queries
	// http://localhost:8080/productos/search/miQuery?precio=50
	@Query("select p from Producto p where p.precio < ?1")   // Query con JPA
	//@NativeQuery("select * from PRODUCTOS where PRECIO < ?")   // Query con SQL
	public List<Producto> miQuery(double precio);

}
