package es.indra;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.business.IProductosBS;
import es.indra.entities.Producto;
import es.indra.persistence.ProductosDAO;

@SpringBootApplication
public class Ejemplo17JdbcApplication implements CommandLineRunner {

	private IProductosBS bs;

	public Ejemplo17JdbcApplication(IProductosBS bs) {
		super();
		this.bs = bs;
	}

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo17JdbcApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		bs.insertarProducto(new Producto(7, "Impresora", 150));
		
		bs.eliminarProducto(1);
		
		bs.modificarProducto(new Producto(7, "Impresora", 136.90));
		
		bs.consultarTodos().forEach(System.out::println);
		System.out.println("---------------------------");

		System.out.println("Encontrado: " + bs.buscarProducto(2));

	}

}
