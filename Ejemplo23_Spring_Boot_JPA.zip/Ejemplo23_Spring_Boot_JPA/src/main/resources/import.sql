-- carga inicial de datos
insert into PRODUCTOS (ID_PRODUCTO, DESCRIPCION, PRECIO) values (1, 'Monitor', 129.50);
insert into PRODUCTOS (ID_PRODUCTO, DESCRIPCION, PRECIO) values (2, 'Teclado', 50.89);
insert into PRODUCTOS (ID_PRODUCTO, DESCRIPCION, PRECIO) values (3, 'Raton', 25.95);
insert into PRODUCTOS (ID_PRODUCTO, DESCRIPCION, PRECIO) values (4, 'Scanner', 230);
insert into PRODUCTOS (ID_PRODUCTO, DESCRIPCION, PRECIO) values (5, 'Pizarra digital', 500);
insert into PRODUCTOS (ID_PRODUCTO, DESCRIPCION, PRECIO) values (6, 'Disco Duro', 89.75);