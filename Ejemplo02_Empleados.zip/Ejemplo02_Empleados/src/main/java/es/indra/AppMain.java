package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// 1º Leer el applicationContext.xml,  
		// 2ª por cada bean declarado crear el bean y lo mete en el contenedor
		ApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		System.out.println(contenedor.getBean("empleado1"));
		System.out.println(contenedor.getBean("empleado2"));
		System.out.println(contenedor.getBean("empleado3"));
		System.out.println(contenedor.getBean("empleado4"));
		System.out.println(contenedor.getBean("empleado5"));
		

	}

}
