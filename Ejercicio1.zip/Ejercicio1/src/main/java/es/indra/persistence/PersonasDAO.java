package es.indra.persistence;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import es.indra.models.Persona;

@Repository
public class PersonasDAO {

	// En versiones nuevas de Spring no se recomiendo utilizar @Autowired por
	// seguridad
	// A cambio se inyecta a traves del constructor
	// @Autowired
	private JdbcTemplate template;

	// @Autowired
	private RowMapper<Persona> mapeadorPersona;

	public PersonasDAO(JdbcTemplate template, RowMapper<Persona> mapeadorPersona) {
		super();
		this.template = template;
		this.mapeadorPersona = mapeadorPersona;
	}

	public List<Persona> consultarTodos() {
		return template.query("select * from PERSONAS", mapeadorPersona);
	}

	public Persona buscarPersona(String dni) {
		return template.queryForObject("select * from PERSONAS where DNI=?", mapeadorPersona, dni);
	}

	public void altaPersona(Persona persona) {
		String sql = "insert into PERSONAS values (?,?,?,?,?)";
		template.update(sql, persona.getDni(), persona.getNombre(), persona.getFechaNac(), persona.getDireccion(),
				persona.getTelefono());
	}

	public void bajaPersona(String dni) {
		template.update("delete from PERSONAS where DNI=?", dni);
	}

	public void modificarDireccion(String dni, String nuevaDireccion) {
		template.update("update PERSONAS set DIR=? where DNI=?", nuevaDireccion, dni);
	}

	public void crearTabla() {
		// Crear la tabla
		template.update("DROP TABLE PERSONAS if exists");
		String sql = "CREATE TABLE PERSONAS " + "(DNI VARCHAR(15) not NULL, " + "NOMBRE VARCHAR(45), "
				+ "FECNAC DATE, DIR VARCHAR(45), TFNO INTEGER," + "PRIMARY KEY (DNI) )";
		template.update(sql);

		// Crear 5 personas en la tabla
		sql = "insert into PERSONAS values (?,?,?,?,?)";
		template.update(sql, "1111111-A", "Juan", new Date("10/12/1987"), "Real, 27 Madrid", 616111111);
		template.update(sql, "2222222-B", "Maria", new Date("1/2/1989"), "Diagonal, 87 Barcelona", 616222222);
		template.update(sql, "3333333-C", "Pedro", new Date("12/9/2001"), "Mayor, 31 Toledo", 616333333);
		template.update(sql, "4444444-D", "Marta", new Date("16/4/2006"), "Camino, 68 Coruña", 616444444);
		template.update(sql, "5555555-E", "Alvaro", new Date("14/3/2003"), "Alfonso, 22 Ciudad Real", 616555555);

	}

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public RowMapper<Persona> getMapeadorPersona() {
		return mapeadorPersona;
	}

	public void setMapeadorPersona(RowMapper<Persona> mapeadorPersona) {
		this.mapeadorPersona = mapeadorPersona;
	}

}
