package es.indra;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import es.indra.business.OperacionesColeccion;
import es.indra.business.Pruebas;
import es.indra.config.JavaConfig;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// 1º Leer el JavaConfig.class,  
		// 2ª por cada bean declarado, crear el bean y lo mete en el contenedor
		AnnotationConfigApplicationContext contenedor = new AnnotationConfigApplicationContext(JavaConfig.class);
		contenedor.scan("es.indra");
		
		Pruebas pruebas = contenedor.getBean("pruebas", Pruebas.class);
		System.out.println("Valor del contador: " + pruebas.getValorContador());
		System.out.println("Importe de compras: " + pruebas.getImporteCompras());
		pruebas.getClientes().forEach(System.out::println);
		System.out.println("----------------------------------");
		
		OperacionesColeccion opColeccion = contenedor.getBean("opColeccion", OperacionesColeccion.class);
		opColeccion.getMejoresClientes().forEach(System.out::println);
		System.out.println("----------------------------------");
		
		opColeccion.getDatos().forEach(System.out::println);
		System.out.println("----------------------------------");
		
		System.out.println("Mejor compra: " + opColeccion.getMejorCompra());
		System.out.println("Peor compra: " + opColeccion.getPeorCompra());
		
	}

}
