package es.indra.models;

public class Cliente {

	private String nombre;
	private boolean nuevo;
	private String nif;
	private double cifraCompras;

	// recurso estatico
	private static int contador = 1;

	public Cliente() {
		// TODO Auto-generated constructor stub
	}

	public Cliente(String nombre, boolean nuevo, String nif, double cifraCompras) {
		super();
		this.nombre = nombre;
		this.nuevo = nuevo;
		this.nif = nif;
		this.cifraCompras = cifraCompras;
	}

	// Metodos estaticos
	public static int getContador() {
		return contador;
	}

	public static int incrementarContador() {
		return ++contador;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public boolean isNuevo() {
		return nuevo;
	}

	public void setNuevo(boolean nuevo) {
		this.nuevo = nuevo;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public double getCifraCompras() {
		return cifraCompras;
	}

	public void setCifraCompras(double cifraCompras) {
		this.cifraCompras = cifraCompras;
	}

	@Override
	public String toString() {
		return "Cliente [nombre=" + nombre + ", nuevo=" + nuevo + ", nif=" + nif + ", cifraCompras=" + cifraCompras
				+ "]";
	}

}
