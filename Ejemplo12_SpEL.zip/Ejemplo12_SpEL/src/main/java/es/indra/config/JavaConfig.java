package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import es.indra.models.Cliente;

@Configuration
public class JavaConfig {

	@Bean
	public Cliente cliente1() {
		return new Cliente("Juan", false, "B-12345678", 16_000_000);
	}
	
	@Bean
	public Cliente cliente2() {
		return new Cliente("Maria", false, "B-98765432", 6_000_000);
	}
	
	@Bean
	public Cliente cliente3() {
		return new Cliente("Pedro", true, "B-56734591", 12_000_000);
	}

}
