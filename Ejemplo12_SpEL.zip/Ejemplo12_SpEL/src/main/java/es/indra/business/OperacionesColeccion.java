package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import es.indra.models.Cliente;

@Service("opColeccion")
public class OperacionesColeccion {

	@Value("#{pruebas.clientes.?[cifraCompras > 10000000]}")
	private List<Cliente> mejoresClientes;
	
	@Value("#{pruebas.clientes.![nombre + ' | ' + nif]}")
	private List<String> datos;
	
	@Value("#{pruebas.clientes.^[cifraCompras > 10000000]}")
	private Cliente mejorCompra;
	
	@Value("#{pruebas.clientes.$[cifraCompras > 10000000]}")
	private Cliente peorCompra;

	public List<Cliente> getMejoresClientes() {
		return mejoresClientes;
	}

	public void setMejoresClientes(List<Cliente> mejoresClientes) {
		this.mejoresClientes = mejoresClientes;
	}

	public List<String> getDatos() {
		return datos;
	}

	public void setDatos(List<String> datos) {
		this.datos = datos;
	}

	public Cliente getMejorCompra() {
		return mejorCompra;
	}

	public void setMejorCompra(Cliente mejorCompra) {
		this.mejorCompra = mejorCompra;
	}

	public Cliente getPeorCompra() {
		return peorCompra;
	}

	public void setPeorCompra(Cliente peorCompra) {
		this.peorCompra = peorCompra;
	}

}
