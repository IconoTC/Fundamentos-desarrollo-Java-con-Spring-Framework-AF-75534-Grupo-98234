package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import es.indra.models.Cliente;

@Service
public class Pruebas {

	@Value("#{T(es.indra.models.Cliente).incrementarContador()}")
	private int valorContador;
	
	@Value("#{cliente1.cifraCompras >= 12000000 ? cliente1.cifraCompras : 12000000}")
	private double importeCompras;
	
	@Autowired
	private List<Cliente> clientes;

	public int getValorContador() {
		return valorContador;
	}

	public void setValorContador(int valorContador) {
		this.valorContador = valorContador;
	}

	public double getImporteCompras() {
		return importeCompras;
	}

	public void setImporteCompras(double importeCompras) {
		this.importeCompras = importeCompras;
	}

	public List<Cliente> getClientes() {
		return clientes;
	}

	public void setClientes(List<Cliente> clientes) {
		this.clientes = clientes;
	}

}
