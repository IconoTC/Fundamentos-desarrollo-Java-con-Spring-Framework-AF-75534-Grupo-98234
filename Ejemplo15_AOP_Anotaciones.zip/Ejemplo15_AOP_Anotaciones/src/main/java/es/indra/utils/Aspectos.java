package es.indra.utils;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;

@Service
@Aspect
@EnableAspectJAutoProxy
public class Aspectos {
	
	//@Pointcut("execution(* es.indra.business.Vacaciones.viajar(..))")
	@Pointcut("bean(vacaciones)")
	private void viajar() {}
	
	// Si hay consejos iguales (@Before) los ordena alfabeticamente
	// Si quiero establecer el orden (a,b,c,d, ...)
	
	/* Otras formas de aplicar los aspectos:
	 * 		@Before(value = "execution(* es.indra.business.Vacaciones.viajar(..))")
	 * 		@Before("bean(vacaciones)")
	 * 		@Before("within(@org.springframework.stereotype.Component *)")
	 * 		@Before("bean(*DAO)")
	 * */
	
	@Before("viajar()")
	public void a_facturar() {
		System.out.println("Facturando");
	}
	
	@Before("viajar()")
	public void b_pasarControl() {
		System.out.println("Pasando control");
	}
	
	@Before("viajar()")
	public void c_embarcar() {
		System.out.println("Embarcando");
	}
	
	@Before("viajar()")
	public void d_despegar() {
		System.out.println("Despegando");
	}
	
	@After("viajar()")
	public void aterrizar() {
		System.out.println("Aterrizando");
	}
	
	@AfterReturning("viajar()")
	public void recogerEquipaje() {
		System.out.println("Recogiendo el equipaje");
	}
	
	@AfterThrowing(value = "viajar()", throwing = "ex")
	public void emergencia(Exception ex) {
		System.out.println("Emergencia a bordo");
		System.out.println(ex.getMessage());
	}
	
	@Around("viajar()")
	public void medirTiempo(ProceedingJoinPoint pjp) throws Throwable {
		// antes
		long inicio = System.currentTimeMillis();
		System.out.println("Tomado el tiempo de inicio");
		
		pjp.proceed();
		
		// despues
		long fin = System.currentTimeMillis();
		System.out.println("Tomado el tiempo final");
		System.out.println("Duracion: " + (fin - inicio) + " mseg.");
	}

}
