package es.indra;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import es.indra.business.Vacaciones;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// 1º Leer el applicationContext.xml,  
		// 2ª por cada bean declarado crear el bean y lo mete en el contenedor
		AnnotationConfigApplicationContext appContext = new AnnotationConfigApplicationContext();
		appContext.scan("es.indra");
		appContext.refresh();
		
		Vacaciones vacaciones = appContext.getBean("vacaciones", Vacaciones.class);
		vacaciones.viajar();

	}

}
