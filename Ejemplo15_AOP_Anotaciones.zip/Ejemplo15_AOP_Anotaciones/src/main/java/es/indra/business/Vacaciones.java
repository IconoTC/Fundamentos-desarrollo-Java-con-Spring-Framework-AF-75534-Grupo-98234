package es.indra.business;

import org.springframework.stereotype.Component;

@Component
public class Vacaciones {
	
	public void viajar() throws RuntimeException {
		System.out.println("Nos vamos de vacaciones");
		//throw new RuntimeException("Error ************");
	}

}
