package es.indra.business;

public class Contabilidad {
	
	// Aqui guardamos la unica instancia de la clase
	private static Contabilidad instance = new Contabilidad();
	
	// Contrusctor es privado para evitar la creacion de mas instancias
	private Contabilidad() {
		// TODO Auto-generated constructor stub
	}
	
	// FACTORIA ESTATICA
	// Metodo estatico y publico que retorna la unica instancia de la clase
	public static Contabilidad getInstance() {
		return instance;
	}
	
	// Metodos de logica de negocio
	public void movimiento(String datos) {
		System.out.println("Anotando el movimiento en el libro de contabilidad " + datos);
	}

}
