package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.business.Contabilidad;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// 1º Leer el applicationContext.xml,  
		// 2ª por cada bean declarado crear el bean y lo mete en el contenedor
		ApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Contabilidad contabilidad = contenedor.getBean("contabilidad", Contabilidad.class);
		contabilidad.movimiento("Pago del alquiler");
		contabilidad.movimiento("Amortizacion de maquinaria");
		
		Contabilidad libro = contenedor.getBean("libro", Contabilidad.class);
		libro.movimiento("Pago de nominas");
		libro.movimiento("Compra de material de oficina");
		
		// Comprobar si es el mismo bean
		if (contabilidad == libro) System.out.println("Es el mismo bean");

	}

}
