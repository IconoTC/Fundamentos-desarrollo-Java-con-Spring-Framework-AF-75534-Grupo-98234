package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.support.TransactionTemplate;

import es.indra.persistence.MapeadorProducto;
import es.indra.persistence.ProductosDAO;

@Configuration
public class JavaConfig {
	
	// El bean TransactionManager siempre es obligatorio
	// independientemente del modelo de transaccion elegido
	@Bean
	public DataSourceTransactionManager txManager() {
		DataSourceTransactionManager txManager = new DataSourceTransactionManager();
		txManager.setDataSource(miDataSource());
		return txManager;
	}
	
	// El bean transactionTemplate solo se necesita para las tx programaticas
	@Bean
	public TransactionTemplate txTemplate() {
		TransactionTemplate txTemplate = new TransactionTemplate();
		txTemplate.setTransactionManager(txManager());
		return txTemplate;
	}
	
	@Bean
	public DriverManagerDataSource miDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("org.h2.Driver");
		dataSource.setUrl("jdbc:h2:~/test");
		return dataSource;
	}
	
	@Bean
	public JdbcTemplate template() {
		JdbcTemplate template = new JdbcTemplate();
		template.setDataSource(miDataSource());
		return template;
	}
	
	@Bean
	public MapeadorProducto mapeadorProducto() {
		return new MapeadorProducto();
	}
	
	@Bean
	public ProductosDAO dao() {
		ProductosDAO dao = new ProductosDAO();
		dao.setTemplate(template());
		dao.setMapeadorProducto(mapeadorProducto());
		dao.setTxTemplate(txTemplate());
		return dao;
	}

}
