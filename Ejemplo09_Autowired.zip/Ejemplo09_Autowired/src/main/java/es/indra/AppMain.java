package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.business.Aseguradora;
import es.indra.models.Coche;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// 1º Leer el applicationContext.xml,  
		// 2ª por cada bean declarado crear el bean y lo mete en el contenedor
		ApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		// Recuperar un bean del contenedor
		Coche coche = (Coche) contenedor.getBean("coche");   // id del bean es coche
		
		// Recuperar el bean aseguradora
		Aseguradora aseguradora = contenedor.getBean("aseguradora", Aseguradora.class);
		
		// Ejecutar
		aseguradora.arreglarCoche(coche);

	}

}
