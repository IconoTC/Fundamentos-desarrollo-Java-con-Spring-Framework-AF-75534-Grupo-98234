package es.indra.business;

import es.indra.models.Coche;

public class Aseguradora {

	private String nombre;
	private ITaller taller; // Inyeccion de dependencias

	// Spring necesita el constructor sin argumentos (defecto)
	// para poder crear el bean
	// Toda clase tiene un constructor por defecto, salvo que se declare otro
	public Aseguradora() {
		// TODO Auto-generated constructor stub
	}

	public Aseguradora(String nombre, ITaller taller) {
		super();
		this.nombre = nombre;
		this.taller = taller;
	}

	public void arreglarCoche(Coche coche) {
		taller.reparar(coche);
	}

	// Spring necesita los metodos getter y setter para inyectar dependencias
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public ITaller getTaller() {
		return taller;
	}

	public void setTaller(ITaller taller) {
		this.taller = taller;
	}

}
