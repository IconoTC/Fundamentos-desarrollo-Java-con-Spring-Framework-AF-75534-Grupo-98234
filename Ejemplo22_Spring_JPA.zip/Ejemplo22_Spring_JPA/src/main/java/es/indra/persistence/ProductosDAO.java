package es.indra.persistence;

import java.util.List;

import org.springframework.stereotype.Repository;

import es.indra.entities.Producto;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;

@Repository
public class ProductosDAO {

	private EntityManagerFactory emf;

	public ProductosDAO(EntityManagerFactory emf) {
		super();
		this.emf = emf;
	}

	public List<Producto> consultarTodos() {
		// Al crear el EntityManager se abre una conexion a la BBDD
		EntityManager em = emf.createEntityManager();  // Factoria dinamica
		List<Producto> lista = em.createQuery("select p from Producto p").getResultList();
		em.close();  // cerrar la conexion a la BBDD
		return lista;
	}

	public Producto buscarProducto(int id) {
		EntityManager em = emf.createEntityManager(); 
		Producto producto = em.find(Producto.class, id);
		em.close(); 
		return producto;
	}

	public boolean insertarProducto(Producto producto) {
		boolean insertado = false;
		
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		try {
			et.begin();
			em.persist(producto);	
			et.commit();
			System.out.println("Producto insertado");
			insertado = true;
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}
	
		return insertado;
	}

}
