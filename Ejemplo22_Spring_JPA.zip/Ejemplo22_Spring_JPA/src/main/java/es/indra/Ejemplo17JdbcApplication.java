package es.indra;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.entities.Producto;
import es.indra.persistence.ProductosDAO;

@SpringBootApplication
public class Ejemplo17JdbcApplication implements CommandLineRunner {

	private ProductosDAO dao;

	public Ejemplo17JdbcApplication(ProductosDAO dao) {
		super();
		this.dao = dao;
	}

	// En los proyectos con Spring Boot, el metodo main esta dedicado exclusivamente
	// a Levantar el contexto de Spring (crear el contenedor con los beans
	// declarados)
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo17JdbcApplication.class, args);
	}

	// Este metodo se ejecuta de forma automatica a continuacion del metodo main
	// Lo que me garantiza que ya tengo el contenedor listo con todos los beans
	@Override
	public void run(String... args) throws Exception {

		dao.insertarProducto(new Producto(1, "Teclado", 29.95));
		dao.insertarProducto(new Producto(2, "Raton", 16));
		dao.insertarProducto(new Producto(3, "Pantalla", 129.50));

		dao.consultarTodos().forEach(System.out::println);

		System.out.println("Encontrado: " + dao.buscarProducto(2));

	}

}
