package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@SpringBootApplication
public class Ejemplo17JdbcApplication {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		SpringApplication.run(Ejemplo17JdbcApplication.class, args);
		
		ProductosDAO dao = new ProductosDAO();
		
		dao.insertarProducto(new Producto(6, "Producto 6", 600));
		
		dao.consultarTodos().forEach(System.out::println);
		
		System.out.println("Encontrado: " + dao.buscarProducto(2));
		
	}

}
