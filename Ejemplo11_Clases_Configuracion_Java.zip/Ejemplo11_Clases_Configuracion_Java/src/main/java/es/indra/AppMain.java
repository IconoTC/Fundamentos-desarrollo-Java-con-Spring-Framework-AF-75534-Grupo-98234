package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import es.indra.business.Aseguradora;
import es.indra.config.JavaConfig;
import es.indra.models.Coche;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// 1º Leer el JavaConfig.class,  
		// 2ª por cada bean declarado, crear el bean y lo mete en el contenedor
		ApplicationContext contenedor = new AnnotationConfigApplicationContext(JavaConfig.class);
		
		// Recuperar un bean del contenedor
		Coche coche = (Coche) contenedor.getBean("coche");   // id del bean es coche
		
		// Recuperar el bean aseguradora
		Aseguradora aseguradora = contenedor.getBean("aseguradora", Aseguradora.class);
		
		// Ejecutar
		aseguradora.arreglarCoche(coche);

	}

}
