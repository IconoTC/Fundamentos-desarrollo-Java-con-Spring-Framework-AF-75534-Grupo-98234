package es.indra;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.models.Persona;
import es.indra.persistence.PersonasDAO;

@SpringBootApplication
public class Ejercicio1Application implements CommandLineRunner{
	
	// En versiones nuevas de Spring no se recomiendo utilizar @Autowired por seguridad
	// A cambio se inyecta a traves del constructor
	//@Autowired
	private PersonasDAO dao;
	
	public Ejercicio1Application(PersonasDAO dao) {
		this.dao = dao;
	}

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio1Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		dao.crearTabla();
		
		dao.altaPersona(new Persona("1111111-A", "Juan", new Date(1987,12,10), "Real, 27 Madrid", 616111111));
		dao.altaPersona(new Persona("2222222-B", "Maria", new Date(1989,2,1), "Diagonal, 87 Barcelona", 616222222));
		dao.altaPersona(new Persona("3333333-C", "Pedro", new Date(2001,9,12), "Mayor, 31 Toledo", 616333333));
		dao.altaPersona(new Persona("4444444-D", "Marta", new Date(2006,4,16), "Camino, 68 Coruña", 616444444));
		dao.altaPersona(new Persona("5555555-E", "Alvaro", new Date(2003,3,14), "Alfonso, 22 Ciudad Real", 616555555));
		dao.altaPersona(new Persona("6666666-F", "Elena", new Date(1997, 12, 26), "Gran Via, 12 Madrid", 616666666));
		
		dao.modificarDireccion("4444444-D", "Alcala, 27 Madrid");
		
		dao.bajaPersona("3333333-C");
		
		dao.consultarTodos().forEach(System.out::println);
		System.out.println("----------------------------");
		
		System.out.println("Encontrado: " + dao.buscarPersona("2222222-B"));
		
	}

}
