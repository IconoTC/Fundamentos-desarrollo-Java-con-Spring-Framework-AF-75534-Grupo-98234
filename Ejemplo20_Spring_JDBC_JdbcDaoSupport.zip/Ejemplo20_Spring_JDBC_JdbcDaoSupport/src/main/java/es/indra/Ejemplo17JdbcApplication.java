package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@SpringBootApplication
public class Ejemplo17JdbcApplication implements CommandLineRunner{
	
	@Autowired
	private ProductosDAO dao;

	// En los proyectos con Spring Boot, el metodo main esta dedicado exclusivamente
	// a Levantar el contexto de Spring (crear el contenedor con los beans declarados)
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo17JdbcApplication.class, args);	
	}

	// Este metodo se ejecuta de forma automatica a continuacion del metodo main
	// Lo que me garantiza que ya tengo el contenedor listo con todos los beans
	@Override
	public void run(String... args) throws Exception {
		// Crear la tabla y los datos iniciales
		dao.crearTabla();
		
		dao.insertarProducto(new Producto(6, "Producto 6", 600));
		
		dao.consultarTodos().forEach(System.out::println);
		
		System.out.println("Encontrado: " + dao.buscarProducto(2));
		
	}

}
