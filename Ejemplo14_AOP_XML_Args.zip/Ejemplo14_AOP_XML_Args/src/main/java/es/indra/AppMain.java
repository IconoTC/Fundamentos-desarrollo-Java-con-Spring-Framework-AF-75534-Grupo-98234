package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.business.Vacaciones;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// 1º Leer el applicationContext.xml,  
		// 2ª por cada bean declarado crear el bean y lo mete en el contenedor
		ApplicationContext appContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Vacaciones vacaciones = appContext.getBean("vacaciones", Vacaciones.class);
		vacaciones.viajar("IBE-1234");

	}

}
